using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

#if UNITY_EDITOR
namespace AvatarMenuCreatorGenerator
{
    public partial class ColorMenuGenerator : EditorWindow
    {
        private string GetRelativePath(GameObject obj, GameObject root)
        {
            if (obj == root) return obj.name;

            List<string> path = new();
            Transform current = obj.transform;

            while (current != null && current.gameObject != root)
            {
                path.Insert(0, current.name);
                current = current.parent;
            }

            return string.Join("/", path);
        }

        private string CleanupName(string name)
        {
            if (useCustomNameParse && !string.IsNullOrWhiteSpace(nameParsePattern))
            {
                return ParseNameWithPattern(name, nameParsePattern);
            }

            // "Avatar_ColorRed" -> "ColorRed" �̂悤�ȕϊ�
            if (name.Contains("_"))
            {
                var parts = name.Split('_');
                if (parts.Length > 1)
                {
                    return parts[^1];
                }
            }
            return name;
        }

        private string ParseNameWithPattern(string name, string pattern)
        {
            var parts = name.Split('_', '-', ' ', ',');
            var result = pattern;
            result = Regex.Replace(result, @"\{(\d+)\}", match =>
            {
                int index = int.Parse(match.Groups[1].Value);
                int actualIndex = index - 1;
                return actualIndex >= 0 && actualIndex < parts.Length ? parts[actualIndex] : string.Empty;
            });
            return result;
        }

        // Transform�l�����������`�F�b�N
        private bool IsTransformEqual(RendererInfo a, RendererInfo b)
        {
            const float epsilon = 0.0001f;

            if (!Vector3.Distance(a.localPosition, b.localPosition).Equals(0f) &&
                Vector3.Distance(a.localPosition, b.localPosition) > epsilon)
            {
                return false;
            }

            if (Quaternion.Angle(a.localRotation, b.localRotation) > epsilon)
            {
                return false;
            }

            if (!Vector3.Distance(a.localScale, b.localScale).Equals(0f) &&
                Vector3.Distance(a.localScale, b.localScale) > epsilon)
            {
                return false;
            }

            return true;
        }

        // Bounds����������
        private bool IsBoundsEqual(Bounds a, Bounds b)
        {
            const float epsilon = 0.0001f;

            if (Vector3.Distance(a.center, b.center) > epsilon)
            {
                return false;
            }

            if (Vector3.Distance(a.size, b.size) > epsilon)
            {
                return false;
            }

            return true;
        }

        private void AddPrefabsFromSameFolder()
        {
            if (basePrefab == null) return;

            // basePrefab�̌��ƂȂ�Prefab�A�Z�b�g���擾
            GameObject prefabAsset = PrefabUtility.GetCorrespondingObjectFromSource(basePrefab);

            if (prefabAsset == null)
            {
                EditorUtility.DisplayDialog("�G���[", "�x�[�X�I�u�W�F�N�g��Prefab�C���X�^���X�ł͂���܂���B", "OK");
                return;
            }

            // Prefab�̃p�X���擾
            string prefabPath = AssetDatabase.GetAssetPath(prefabAsset);
            if (string.IsNullOrEmpty(prefabPath))
            {
                EditorUtility.DisplayDialog("�G���[", "Prefab�̃p�X���擾�ł��܂���ł����B", "OK");
                return;
            }

            // �t�H���_�p�X���擾
            string folderPath = System.IO.Path.GetDirectoryName(prefabPath);

            // �t�H���_���̑S�Ă�Prefab������
            string[] guids = AssetDatabase.FindAssets("t:Prefab", new[] { folderPath });

            int addedCount = 0;
            foreach (string guid in guids)
            {
                string assetPath = AssetDatabase.GUIDToAssetPath(guid);

                // �����t�H���_���̂݁i�T�u�t�H���_�����O�j
                if (System.IO.Path.GetDirectoryName(assetPath) != folderPath)
                {
                    continue;
                }

                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);

                if (prefab != null && prefab != prefabAsset && !variationPrefabs.Contains(prefab))
                {
                    variationPrefabs.Add(prefab);
                    addedCount++;
                }
            }

            if (addedCount > 0)
            {
                detectedVariations.Clear();
                Debug.Log($"{addedCount}��Prefab��ǉ����܂���: {folderPath}");
            }
            else
            {
                EditorUtility.DisplayDialog("���", "�ǉ��ł���Prefab��������܂���ł����B", "OK");
            }
        }
    }
}
#endif